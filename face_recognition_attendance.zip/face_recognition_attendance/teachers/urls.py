from django.urls import path
from . import views

urlpatterns = [
    path('view_attendance/<int:course_id>/', views.view_attendance, name='view_attendance'),
]

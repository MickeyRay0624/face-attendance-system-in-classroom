from django.shortcuts import render
from .models import Course

def view_attendance(request, course_id):
    course = Course.objects.get(id=course_id)
    students = course.students.all()
    return render(request, 'teachers/view_attendance.html', {'course': course, 'students': students})

from django import forms
from .models import Student

class DailyPhotoForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['daily_photos']

class AttendanceForm(forms.Form):
    photo = forms.ImageField()

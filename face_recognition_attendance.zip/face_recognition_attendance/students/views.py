from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import DailyPhotoForm, AttendanceForm
from .models import Student, Attendance
import face_recognition
from django.conf import settings
import os


@login_required
def upload_daily_photo(request):
    if request.method == 'POST':
        form = DailyPhotoForm(request.POST, request.FILES)
        if form.is_valid():
            daily_photo = form.save(commit=False)
            daily_photo.student = request.user.student
            daily_photo.save()
            return redirect('profile')
    else:
        form = DailyPhotoForm()
    return render(request, 'students/upload_daily_photo.html', {'form': form})


@login_required
def attendance(request):
    if request.method == 'POST':
        form = AttendanceForm(request.POST, request.FILES)
        if form.is_valid():
            attendance_photo = form.cleaned_data['photo']
            student = request.user.student
            if face_recognition_func(attendance_photo, student):
                Attendance.objects.create(student=student, course=selected_course, status=True)
                return redirect('success')
            else:
                return redirect('fail')
    else:
        form = AttendanceForm()
    return render(request, 'students/attendance.html', {'form': form})


def face_recognition_func(attendance_photo, student):
    known_image = face_recognition.load_image_file(student.daily_photos.path)
    unknown_image = face_recognition.load_image_file(attendance_photo)

    known_encoding = face_recognition.face_encodings(known_image)[0]
    unknown_encoding = face_recognition.face_encodings(unknown_image)[0]

    results = face_recognition.compare_faces([known_encoding], unknown_encoding)

    return results[0]

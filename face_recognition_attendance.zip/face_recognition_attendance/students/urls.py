from django.urls import path
from . import views

urlpatterns = [
    path('upload_daily_photo/', views.upload_daily_photo, name='upload_daily_photo'),
    path('attendance/', views.attendance, name='attendance'),
]

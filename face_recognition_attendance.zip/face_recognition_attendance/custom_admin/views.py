from django.shortcuts import render, redirect
from teachers.models import Course
from students.models import Student
from django.contrib.auth.models import User
from .forms import CourseForm, UserForm

def manage_courses(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_courses')
    else:
        form = CourseForm()
    courses = Course.objects.all()
    return render(request, 'custom_admin/manage_courses.html', {'form': form, 'courses': courses})

def manage_users(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_users')
    else:
        form = UserForm()
    users = User.objects.all()
    return render(request, 'custom_admin/manage_users.html', {'form': form, 'users': users})

from django.db import models
from django.contrib.auth.models import User
from teachers.models import Course
from students.models import Student

# Additional custom_admin models if needed

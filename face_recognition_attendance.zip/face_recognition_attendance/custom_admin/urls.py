from django.urls import path
from . import views

urlpatterns = [
    path('manage_courses/', views.manage_courses, name='manage_courses'),
    path('manage_users/', views.manage_users, name='manage_users'),
]
